import { useEffect } from "react";
import * as maplibregl from "maplibre-gl";
import type { Map as MapLibreMap } from "maplibre-gl";

import { useMap } from "./map-context";

import type { BuildingFeatureCollection } from "@/lib/map/buildingVisibility";
import type { RouteKind } from "@/types/routes";

import { BUILDINGS_EXTRUSION_LAYER_ID } from "@/lib/map/layers";

const SOURCE_ID = "coolroute-campus-building-cells";
const FILL_LAYER_ID = "coolroute-campus-building-zones";
const OUTLINE_LAYER_ID = "coolroute-campus-building-zone-outlines";

interface Props {
  selectedRouteKind: RouteKind;
}

async function addCampusOverlay(
  mapInstance: MapLibreMap,
  signal: AbortSignal,
): Promise<void> {
  try {
    const response = await fetch(
      `${import.meta.env.BASE_URL}data/campus-buildings-optimized.geojson`,
      { signal },
    );

    if (!response.ok) {
      throw new Error("Could not load campus building coverage.");
    }

    const data = (await response.json()) as BuildingFeatureCollection;

    if (signal.aborted) return;

    for (const id of [OUTLINE_LAYER_ID, FILL_LAYER_ID]) {
      if (mapInstance.getLayer(id)) {
        mapInstance.removeLayer(id);
      }
    }

    if (mapInstance.getSource(SOURCE_ID)) {
      mapInstance.removeSource(SOURCE_ID);
    }

    mapInstance.addSource(SOURCE_ID, {
      type: "geojson",
      data,
      maxzoom: 18,
      buffer: 32,
      tolerance: 0.375,
    } as Parameters<typeof mapInstance.addSource>[1]);

    const beforeId = mapInstance.getLayer(BUILDINGS_EXTRUSION_LAYER_ID)
      ? BUILDINGS_EXTRUSION_LAYER_ID
      : mapInstance.getStyle().layers.find((layer) => layer.type === "symbol")
          ?.id;

    mapInstance.addLayer(
      {
        id: FILL_LAYER_ID,
        type: "fill",
        source: SOURCE_ID,
        minzoom: 14,
        paint: {
          "fill-color": "#C9D8C9",
          "fill-opacity": [
            "interpolate",
            ["linear"],
            ["zoom"],
            14,
            0.12,
            17,
            0.24,
            19,
            0.3,
          ],
          "fill-antialias": true,
        },
      } as maplibregl.FillLayerSpecification,
      beforeId,
    );

    mapInstance.addLayer(
      {
        id: OUTLINE_LAYER_ID,
        type: "line",
        source: SOURCE_ID,
        minzoom: 16,
        paint: {
          "line-color": "#91A591",
          "line-width": [
            "interpolate",
            ["linear"],
            ["zoom"],
            16,
            0.35,
            19,
            0.75,
          ],
          "line-opacity": 0.22,
          "line-blur": 0.25,
        },
      } as maplibregl.LineLayerSpecification,
      beforeId,
    );

    console.info(
      `[buildings] ${data.features.length} campus coverage regions added as ground overlays.`,
    );
  } catch (error) {
    if (!signal.aborted) {
      console.error("[buildings] Campus overlay failed:", error);
    }
  }
}

export function CampusBuildingCellsLayer({
  selectedRouteKind: _selectedRouteKind,
}: Props) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    const controller = new AbortController();

    void addCampusOverlay(map, controller.signal);

    return () => {
      controller.abort();

      for (const id of [OUTLINE_LAYER_ID, FILL_LAYER_ID]) {
        if (map.getLayer(id)) {
          map.removeLayer(id);
        }
      }

      if (map.getSource(SOURCE_ID)) {
        map.removeSource(SOURCE_ID);
      }
    };
  }, [map]);

  return null;
}
